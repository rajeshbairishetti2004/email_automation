<?php
// view_report.php
// - Lists all stored clients (with search + paging)
// - Shows single report with next/prev navigation, print button
// - Inline editable greeting/intro/closing/rationale with AJAX -> DB
// - Same simple auth as client_report.php
// - Send current client report by email using PHPMailer

session_start();

const ADMIN_USER = 'admin';
const ADMIN_PASS = 'admin123'; // must match client_report.php

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_user'], $_POST['login_pass'])) {
        if ($_POST['login_user'] === ADMIN_USER && $_POST['login_pass'] === ADMIN_PASS) {
            $_SESSION['logged_in'] = true;
            header('Location: view_report.php');
            exit;
        }
        $login_error = 'Invalid credentials';
    }

    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Login - View Reports</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            form { max-width: 320px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 6px; }
            label { display: block; margin-top: 10px; }
            input { width: 100%; padding: 6px; margin-top: 4px; }
            button { margin-top: 15px; padding: 8px 16px; }
            .error { color: #b30000; margin-top: 10px; }
        </style>
    </head>
    <body>
    <h1>View Reports Login</h1>
    <form method="post">
        <label>Username
            <input type="text" name="login_user" required>
        </label>
        <label>Password
            <input type="password" name="login_pass" required>
        </label>
        <button type="submit">Login</button>
        <?php if (!empty($login_error)): ?>
            <div class="error"><?php echo htmlspecialchars($login_error); ?></div>
        <?php endif; ?>
    </form>
    </body>
    </html>
    <?php
    exit;
}

/* ---------- DB ---------- */

const DB_HOST = 'localhost';
const DB_NAME = 'client_reports';
const DB_USER = 'root';
const DB_PASS = '';

function getPdo(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
    }
    return $pdo;
}

function formatRupeesLakhs(float $amount, bool $lakhs = true): string {
    if ($lakhs) {
        $v = $amount / 100000;
        return 'Rs.' . number_format($v, 2) . ' lakhs';
    }
    return 'Rs.' . number_format($amount, 2);
}

function formatPercent(float $v): string {
    return number_format($v, 2) . '%';
}

/* ---------- PHPMailer (for email sending) ---------- */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php';

/* ---------- AJAX SCHEME UPDATE HANDLER ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_scheme']) && $_POST['ajax_scheme'] === '1') {
    header('Content-Type: application/json');

    try {
        $pdo = getPdo();
        $schemeId = (int)($_POST['scheme_id'] ?? 0);

        if (!$schemeId) {
            throw new Exception('Invalid scheme ID');
        }

        $updates = [];
        $params = [':id' => $schemeId];

        if (isset($_POST['action_step'])) {
            $updates[] = 'action_step = :action_step';
            $params[':action_step'] = $_POST['action_step'];
        }

        if (isset($_POST['recommended_scheme'])) {
            $updates[] = 'recommended_scheme = :recommended_scheme';
            $params[':recommended_scheme'] = $_POST['recommended_scheme'];
        }

        if (isset($_POST['recommended_amount'])) {
            $updates[] = 'recommended_amount = :recommended_amount';
            $params[':recommended_amount'] = (float)$_POST['recommended_amount'];
        }

        if (!empty($updates)) {
            $sql = "UPDATE client_schemes SET " . implode(', ', $updates) . " WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
        }

        echo json_encode(['success' => true]);
    } catch (Throwable $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage(),
        ]);
    }
    exit;
}

/* ---------- AJAX EDIT HANDLER ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === '1') {
    header('Content-Type: application/json');

    try {
        $pdo      = getPdo();
        $clientId = (int)($_POST['client_id'] ?? 0);
        $field    = $_POST['field'] ?? '';
        $value    = $_POST['value'] ?? '';

        if (!$clientId || !in_array($field, ['greeting','intro','closing','rationale','client_message'], true)) {
            throw new Exception('Invalid input');
        }

        // ✅ NEW: Handle merged client message
        if ($field === 'client_message') {
            // Parse the message to extract parts
            $lines = explode("\n\n", $value);
            
            // First paragraph = greeting
            $greeting = isset($lines[0]) ? trim($lines[0]) : '';
            
            // Middle paragraphs = intro
            $introParts = array_slice($lines, 1, -1);
            $intro = !empty($introParts) ? implode("\n\n", $introParts) : '';
            
            // Last paragraph = closing
            $closing = isset($lines[count($lines) - 1]) && count($lines) > 1 ? trim($lines[count($lines) - 1]) : '';
            
            // Update all three fields
            $sql = "UPDATE clients SET greeting_prefix = :greeting, intro_text = :intro, closing_text = :closing WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':greeting' => $greeting,
                ':intro'    => $intro,
                ':closing'  => $closing,
                ':id'       => $clientId,
            ]);
            
            echo json_encode(['success' => true]);
            exit;
        }

        switch ($field) {
            case 'greeting':
                $column = 'greeting_prefix';
                break;
            case 'intro':
                $column = 'intro_text';
                break;
            case 'closing':
                $column = 'closing_text';
                break;
            case 'rationale':
                $column = 'rationale_text';
                break;
            default:
                throw new Exception('Unknown field');
        }

        $sql = "UPDATE clients SET {$column} = :val WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':val' => $value,
            ':id'  => $clientId,
        ]);

        echo json_encode(['success' => true]);
    } catch (Throwable $e) {
        echo json_encode([
            'success' => false,
            'error'   => $e->getMessage(),
        ]);
    }
    exit;
}

/* ---------- HANDLE "SEND EMAIL" REQUEST ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_email']) && $_POST['send_email'] == '1') {
    $pdo = getPdo();
    $clientId  = (int)($_POST['client_id'] ?? 0);
    $rawEmails = trim($_POST['recipient_email'] ?? '');

    // split by comma or semicolon, trim each
    $emailList = array_filter(
        array_map('trim', preg_split('/[;,]+/', $rawEmails))
    );

    if ($clientId <= 0 || empty($emailList)) {
        header('Location: view_report.php?id=' . $clientId);
        exit;
    }

    // Load client + related data
    $stmt = $pdo->prepare("SELECT * FROM clients WHERE id = :id");
    $stmt->execute([':id' => $clientId]);
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($client) {
        $stmt = $pdo->prepare("SELECT * FROM client_goals WHERE client_id = :id ORDER BY id ASC");
        $stmt->execute([':id' => $clientId]);
        $goals = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT * FROM client_allocations WHERE client_id = :id ORDER BY id ASC");
        $stmt->execute([':id' => $clientId]);
        $allocations = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT * FROM client_schemes WHERE client_id = :id ORDER BY id ASC");
        $stmt->execute([':id' => $clientId]);
        $schemes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("SELECT * FROM client_annexures WHERE client_id = :id ORDER BY id ASC");
        $stmt->execute([':id' => $clientId]);
        $annexures = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $name        = $client['name'];
        $asOn        = $client['as_on'] ?? '';
        $totalAmount = (float)($client['total_amount'] ?? 0);
        $profit      = (float)($client['profit'] ?? 0);
        $cagr        = (float)($client['cagr'] ?? 0);
        $xirr        = (float)($client['xirr'] ?? 0);
        $totalGoalCurrent = (float)($client['total_goal_current'] ?? 0);
        $totalGoalTarget  = (float)($client['total_goal_target'] ?? 0);
        $totalSip         = (float)($client['total_sip'] ?? 0);

        // ----- text fields (same logic as detail view) -----
        $greetingStored    = trim((string)($client['greeting_prefix'] ?? ''));
        $introTextStored   = trim((string)($client['intro_text'] ?? ''));
        $closingTextStored = trim((string)($client['closing_text'] ?? ''));
        $rationaleStored   = trim((string)($client['rationale_text'] ?? ''));

        $DEFAULT_GREETING  = 'Dear Mr.';
        $DEFAULT_INTRO     = 'Introduction';
        $DEFAULT_CLOSING   = 'Closing remarks';
        $DEFAULT_RATIONALE = 'Rationale for recommendations';

        // ✅ Build merged client message for email
        $clientMessageParts = [];
        
        if ($greetingStored !== '') {
            $clientMessageParts[] = $greetingStored;
        } else {
            $clientMessageParts[] = $DEFAULT_GREETING . ' ' . $name . ',';
        }
        
        if ($introTextStored !== '') {
            $clientMessageParts[] = $introTextStored;
        }
        
        if ($closingTextStored !== '') {
            $clientMessageParts[] = $closingTextStored;
        }
        
        $clientMessage = implode("\n\n", $clientMessageParts);
        $rationaleText = $rationaleStored !== '' ? $rationaleStored : $DEFAULT_RATIONALE;

        // Build HTML email body
        ob_start();
        ?>
        <html>
        <body style="font-family: Arial, sans-serif; font-size: 13px;">
        
        <!-- ✅ Use merged client message -->
        <?php echo nl2br(htmlspecialchars($clientMessage)); ?>

        <h4>1. Current Situation</h4>
        <table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse; font-size: 12px;">
            <tr>
                <th colspan="2">Current Situation</th>
            </tr>
            <tr>
                <td>Total Amount as of <?php echo htmlspecialchars($asOn); ?></td>
                <td><?php echo formatRupeesLakhs($totalAmount); ?></td>
            </tr>
            <tr>
                <td>CAGR of current schemes</td>
                <td><?php echo formatPercent($cagr); ?></td>
            </tr>
            <?php if ($xirr != 0): ?>
                <tr>
                    <td>XIRR of all schemes since inception</td>
                    <td><?php echo formatPercent($xirr); ?></td>
                </tr>
            <?php endif; ?>
            <tr>
                <td>Profit since inception</td>
                <td><?php echo formatRupeesLakhs($profit); ?></td>
            </tr>
        </table>

        <h4>2. Objectives Progress</h4>
        <table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse; font-size: 12px;">
            <tr>
                <th>Goal</th>
                <th>Target Year</th>
                <th>Current Amount</th>
                <th>SIP/SWP</th>
                <th>Target Amount</th>
                <th>Status</th>
            </tr>
            <?php foreach ($goals as $g): ?>
                <tr>
                    <td><?php echo htmlspecialchars($g['goal']); ?></td>
                    <td><?php echo htmlspecialchars(substr((string)$g['goal_date'], -4)); ?></td>
                    <td><?php echo formatRupeesLakhs((float)$g['current_amount']); ?></td>
                    <td><?php echo 'Rs.' . number_format(((float)$g['sip_swp']) / 1000, 1) . 'k'; ?></td>
                    <td><?php echo formatRupeesLakhs((float)$g['target_amount']); ?></td>
                    <td><?php echo htmlspecialchars($g['status']); ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td><strong>Total</strong></td>
                <td></td>
                <td><?php echo formatRupeesLakhs($totalGoalCurrent); ?></td>
                <td><?php echo 'Rs.' . number_format($totalSip / 1000, 1) . 'k'; ?></td>
                <td><?php echo $totalGoalTarget ? formatRupeesLakhs($totalGoalTarget) : ''; ?></td>
                <td></td>
            </tr>
        </table>

        <h4>3. Asset Allocation</h4>
        <table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse; font-size: 12px;">
            <tr>
                <th>Asset</th>
                <th>Share %</th>
            </tr>
            <?php foreach ($allocations as $a): ?>
                <tr>
                    <td><?php echo htmlspecialchars($a['asset']); ?></td>
                    <td><?php echo number_format((float)$a['share_pct'], 0); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>

        <h4>4. Schemes</h4>
        <table border="1" cellpadding="4" cellspacing="0" style="border-collapse: collapse; font-size: 12px;">
            <tr>
                <th>Scheme Name</th>
                <th>SIP/SWP</th>
                <th>Current Value</th>
                <th>Action Step</th>
            </tr>
            <?php foreach ($schemes as $s): ?>
                <tr>
                    <td><?php echo htmlspecialchars($s['scheme_name']); ?></td>
                    <td><?php echo (float)$s['sip_swp'] ? number_format((float)$s['sip_swp'], 0) : '0'; ?></td>
                    <td><?php echo formatRupeesLakhs((float)$s['current_value']); ?></td>
                    <td><?php echo htmlspecialchars($s['action_step'] ?? 'Continue'); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>

        <?php if (trim($rationaleText) !== ''): ?>
            <h4>Rationale</h4>
            <p><?php echo nl2br(htmlspecialchars($rationaleText)); ?></p>
        <?php endif; ?>

        <?php if ($annexures): ?>
            <h4>Annexures</h4>
            <ul>
                <?php foreach ($annexures as $ax): ?>
                    <li><?php echo htmlspecialchars($ax['line_text']); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <p>Regards,<br>Your Advisor</p>
        </body>
        </html>
        <?php
        $emailHtml = ob_get_clean();

        // Get client name dynamically (already available)
        $clientName = $name;
        
        // Use report date from Excel files instead of current date
        if (!empty($asOn)) {
            // Try to parse the date from the report (formats: dd-mm-yyyy or dd/mm/yyyy)
            $dateObj = DateTime::createFromFormat('d-m-Y', $asOn);
            if (!$dateObj) {
                $dateObj = DateTime::createFromFormat('d/m/Y', $asOn);
            }
            if (!$dateObj) {
                // Fallback to strtotime if above formats fail
                $dateObj = new DateTime($asOn);
            }
            
            $month = $dateObj->format('M');    // Jan, Feb, Mar, etc.
            $year = $dateObj->format('Y');     // 2024, 2025, etc.
        } else {
            // Fallback to current date if report date is not available
            $month = date('M');
            $year = date('Y');
        }
        
        // Build dynamic subject
        $dynamicSubject = "$clientName - Quarterly Review $month $year";

        // Send email via PHPMailer
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;

            $mail->Username   = 'rajeshbairisetti234@gmail.com';   // your Gmail
            $mail->Password   = 'ruew bbri fuac djsc';             // your Google App Password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;    // TLS
            $mail->Port       = 587;                               // TLS port
            $mail->CharSet    = 'UTF-8';

            $mail->setFrom('rajeshbairisetti234@gmail.com', 'Portfolio Reports');

            // send to all emails entered in the form
            foreach ($emailList as $email) {
                $mail->addAddress($email);
            }

            $mail->Subject = $dynamicSubject;  // ✅ Use dynamic subject instead of hardcoded
            $mail->isHTML(true);
            $mail->Body = $emailHtml;

            $mail->send();
            header('Location: view_report.php?id=' . $clientId . '&sent=1');
            exit;
        } catch (Exception $e) {
            // Optional: log $e->getMessage()
            header('Location: view_report.php?id=' . $clientId . '&sent_error=1');
            exit;
        }
    } else {
        // No client found for that ID
        header('Location: view_report.php');
        exit;
    }
}

/* ---------- LIST VS DETAIL ---------- */

$pdo = getPdo();
$clientId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

/* ----- LIST VIEW ----- */

if ($clientId <= 0) {
    $q      = isset($_GET['q']) ? trim($_GET['q']) : '';
    $page   = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $limit  = 20;
    $offset = ($page - 1) * $limit;

    $where  = '';
    $params = [];

    if ($q !== '') {
        $where = "WHERE name LIKE :q OR as_on LIKE :q";
        $params[':q'] = '%' . $q . '%';
    }

    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM clients {$where}");
    $stmtCount->execute($params);
    $totalRows = (int)$stmtCount->fetchColumn();
    $totalPages = max(1, (int)ceil($totalRows / $limit));

    $stmt = $pdo->prepare("
        SELECT id, name, as_on, created_at, total_amount, profit
        FROM clients
        {$where}
        ORDER BY created_at DESC, id DESC
        LIMIT :limit OFFSET :offset
    ");
    foreach ($params as $k => $v) {
        $stmt->bindValue($k, $v, PDO::PARAM_STR);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Stored Client Reports</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { margin-bottom: 10px; }
            table { border-collapse: collapse; width: 100%; margin-top: 20px; }
            th, td { border: 1px solid #ccc; padding: 8px; font-size: 13px; }
            th { background-color: #f0f0f0; }
            a { text-decoration: none; color: #0056b3; }
            a:hover { text-decoration: underline; }

            .nav-bar { margin-bottom: 20px; }
            .nav-button {
                display: inline-block;
                margin-right: 10px;
                padding: 6px 12px;
                background-color: #0056b3;
                color: #fff;
                border-radius: 4px;
                text-decoration: none;
                font-size: 13px;
            }
            .nav-button:hover { background-color: #003f82; }

            .search-box { margin-top: 10px; }
            .pagination { margin-top: 10px; font-size: 13px; }
            .pagination a { margin-right: 5px; }
        </style>
    </head>
    <body>

    <div class="nav-bar">
        <a href="client_report.php" class="nav-button">Upload New Files</a>
        <a href="view_report.php" class="nav-button">View Saved Reports</a>
    </div>

    <h1>Stored Client Reports</h1>

    <form method="get" class="search-box">
        <input type="text" name="q" placeholder="Search by name or date..." value="<?php echo htmlspecialchars($q); ?>">
        <button type="submit">Search</button>
    </form>

    <?php if (!$clients): ?>
        <p>No reports found. Try uploading from <a href="client_report.php">Upload Page</a>.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Client Name</th>
                <th>As On</th>
                <th>Total Amount</th>
                <th>Profit</th>
                <th>Created At</th>
                <th>View</th>
            </tr>
            <?php foreach ($clients as $c): ?>
                <tr>
                    <td><?php echo (int)$c['id']; ?></td>
                    <td><?php echo htmlspecialchars($c['name']); ?></td>
                    <td><?php echo htmlspecialchars($c['as_on']); ?></td>
                    <td><?php echo formatRupeesLakhs((float)$c['total_amount']); ?></td>
                    <td><?php echo formatRupeesLakhs((float)$c['profit']); ?></td>
                    <td><?php echo htmlspecialchars($c['created_at']); ?></td>
                    <td><a href="view_report.php?id=<?php echo (int)$c['id']; ?>">Open</a></td>
                </tr>
            <?php endforeach; ?>
        </table>

        <div class="pagination">
            Page <?php echo $page; ?> of <?php echo $totalPages; ?>:
            <?php
            for ($p = 1; $p <= $totalPages; $p++) {
                if ($p == $page) {
                    echo "<strong>{$p}</strong> ";
                } else {
                    $params = ['page' => $p];
                    if ($q !== '') $params['q'] = $q;
                    $url = 'view_report.php?' . http_build_query($params);
                    echo "<a href=\"{$url}\">{$p}</a> ";
                }
            }
            ?>
        </div>
    <?php endif; ?>

    </body>
    </html>
    <?php
    exit;
}

/* ----- DETAIL VIEW ----- */

$stmt = $pdo->prepare("SELECT * FROM clients WHERE id = :id");
$stmt->execute([':id' => $clientId]);
$client = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$client) {
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Report Not Found</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            a { text-decoration: none; color: #0056b3; }
        </style>
    </head>
    <body>
        <p>No report found for ID <?php echo htmlspecialchars((string)$clientId); ?>.</p>
        <p><a href="view_report.php">&larr; Back to list</a></p>
    </body>
    </html>
    <?php
    exit;
}

// Next / Prev IDs
$stmtPrev = $pdo->prepare("SELECT id FROM clients WHERE id < :id ORDER BY id DESC LIMIT 1");
$stmtPrev->execute([':id' => $clientId]);
$prevId = $stmtPrev->fetchColumn();

$stmtNext = $pdo->prepare("SELECT id FROM clients WHERE id > :id ORDER BY id ASC LIMIT 1");
$stmtNext->execute([':id' => $clientId]);
$nextId = $stmtNext->fetchColumn();

$stmt = $pdo->prepare("SELECT * FROM client_goals WHERE client_id = :id ORDER BY id ASC");
$stmt->execute([':id' => $clientId]);
$goals = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT * FROM client_allocations WHERE client_id = :id ORDER BY id ASC");
$stmt->execute([':id' => $clientId]);
$allocations = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT * FROM client_schemes WHERE client_id = :id ORDER BY id ASC");
$stmt->execute([':id' => $clientId]);
$schemes = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT * FROM client_annexures WHERE client_id = :id ORDER BY id ASC");
$stmt->execute([':id' => $clientId]);
$annexures = $stmt->fetchAll(PDO::FETCH_ASSOC);

$name              = $client['name'];
$asOn              = $client['as_on'] ?? '';  // ✅ Fixed - this is your $AsOn variable
$totalAmount       = (float)($client['total_amount'] ?? 0);
$profit            = (float)($client['profit'] ?? 0);
$cagr              = (float)($client['cagr'] ?? 0);
$xirr              = (float)($client['xirr'] ?? 0);
$totalGoalCurrent  = (float)($client['total_goal_current'] ?? 0);
$totalGoalTarget   = (float)($client['total_goal_target'] ?? 0);
$totalSip          = (float)($client['total_sip'] ?? 0);

$greetingStored    = trim((string)($client['greeting_prefix'] ?? ''));
$introTextStored   = trim((string)($client['intro_text'] ?? ''));
$closingTextStored = trim((string)($client['closing_text'] ?? ''));
$rationaleStored   = trim((string)($client['rationale_text'] ?? ''));

$DEFAULT_GREETING  = 'Dear Mr.';
$DEFAULT_INTRO     = 'Introduction';
$DEFAULT_CLOSING   = 'Closing remarks';
$DEFAULT_RATIONALE = 'Rationale for recommendations';

// ✅ MERGED: Combine greeting, intro, and closing into ONE message
$clientMessageParts = [];

// Add greeting
if ($greetingStored !== '') {
    $clientMessageParts[] = $greetingStored;
} else {
    $clientMessageParts[] = $DEFAULT_GREETING . ' ' . $name . ',';
}

// Add intro
if ($introTextStored !== '') {
    $clientMessageParts[] = $introTextStored;
} else {
    $clientMessageParts[] = "I am sure that all of you are safe and fine. I am pleased to send your quarterly portfolio review. The portfolio is doing well, and the scheme selection is good. Almost all schemes are showing good comparative performance and can be continued.";
}

// Add closing
if ($closingTextStored !== '') {
    $clientMessageParts[] = $closingTextStored;
} else {
    $clientMessageParts[] = "We are very keen to have a portfolio discussion meeting with you to discuss the portfolio. Please let us know at your convenience.";
}

$clientMessage = implode("\n\n", $clientMessageParts);

$rationaleText = $rationaleStored !== '' ? $rationaleStored : $DEFAULT_RATIONALE;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Client Report - <?php echo htmlspecialchars($name); ?></title>
    
    <!-- Modern Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Modern Styling -->
    <link rel="stylesheet" href="public/css/styles.css">
    
    <style>
        /* Additional specific styles for view_report.php */
        .report-table {
            width: 70%;
            margin: 0 auto 20px 0;
        }
        .report-table.small {
            width: 40%;
        }
        
        .client-report {
            page-break-after: always;
        }
    </style>
</head>
<body>

<div class="nav-bar">
    <a href="view_report.php" class="nav-button">&larr; Back to list</a>
    <a href="client_report.php" class="nav-button">Upload New Files</a>
    <?php if ($prevId): ?>
        <a href="view_report.php?id=<?php echo (int)$prevId; ?>" class="nav-button">&larr; Previous</a>
    <?php endif; ?>
    <?php if ($nextId): ?>
        <a href="view_report.php?id=<?php echo (int)$nextId; ?>" class="nav-button">Next &rarr;</a>
    <?php endif; ?>
    <button type="button" onclick="window.print()" class="nav-button">Print</button>
</div>

<?php if (isset($_GET['sent']) && $_GET['sent'] == '1'): ?>
    <div class="flash-success">Email sent successfully.</div>
<?php elseif (isset($_GET['sent_error']) && $_GET['sent_error'] == '1'): ?>
    <div class="flash-error">Failed to send email. Please check SMTP settings.</div>
<?php endif; ?>

<!-- Email form for this client -->
<div style="margin-bottom: 20px;">
    <form method="post" style="display: inline-flex; gap: 8px; align-items: center;">
        <input type="hidden" name="send_email" value="1">
        <input type="hidden" name="client_id" value="<?php echo (int)$clientId; ?>">

        <input type="email" name="recipient_email" multiple
               required
               placeholder="Enter one or more emails, separated by commas"
               style="padding: 4px 8px; font-size: 13px; width: 350px;">

        <button type="submit" class="nav-button" style="padding: 4px 10px;">
            Send Report by Email
        </button>
    </form>
</div>

<h1>Client Report</h1>
<h2><?php echo htmlspecialchars($name); ?></h2>

<div class="client-report" data-client-id="<?php echo (int)$clientId; ?>">

    <!-- ✅ MERGED: ONE unified client communication textarea -->
    <div class="card">
        <label class="card-title">Client Communication</label>
        <textarea class="large-textarea" 
                  data-field="client_message" 
                  data-client-id="<?php echo (int)$clientId; ?>"
                  placeholder="Write your greeting, introduction, and closing remarks here..."><?php echo htmlspecialchars($clientMessage); ?></textarea>
        <p style="font-size: 12px; color: #666; margin-top: 8px;">
            💡 This message will appear at the top of the email and printed report
        </p>
    </div>

    <h3>1. Current Situation</h3>
    <table class="report-table">
        <tr><th colspan="2">Current Situation</th></tr>
        <tr>
            <td>Total Amount as of <?php echo htmlspecialchars($asOn); ?></td>
            <td><?php echo formatRupeesLakhs($totalAmount); ?></td>
        </tr>
        <tr>
            <td>CAGR of current schemes</td>
            <td><?php echo formatPercent($cagr); ?></td>
        </tr>
        <?php if ($xirr != 0): ?>
            <tr>
                <td>XIRR of all schemes since inception</td>
                <td><?php echo formatPercent($xirr); ?></td>
            </tr>
        <?php endif; ?>
        <tr>
            <td>Profit since inception</td>
            <td><?php echo formatRupeesLakhs($profit); ?></td>
        </tr>
    </table>

    <h3>2. Objectives Progress for guiding on appropriate schemes</h3>
    <table class="report-table">
        <tr>
            <th>Goal/s</th>
            <th>Target Year</th>
            <th>Current Amount (Rs)</th>
            <th>SIP/SWP</th>
            <th>Target Amount (Rs)</th>
            <th>Status</th>
        </tr>
        <?php foreach ($goals as $g): ?>
            <tr>
                <td><?php echo htmlspecialchars($g['goal']); ?></td>
                <td><?php
                    $year = '';
                    if (!empty($g['goal_date'])) {
                        $year = substr($g['goal_date'], -4);
                    }
                    echo htmlspecialchars($year);
                ?></td>
                <td><?php echo formatRupeesLakhs((float)$g['current_amount']); ?></td>
                <td><?php echo 'Rs.' . number_format(((float)$g['sip_swp']) / 1000, 1) . 'k'; ?></td>
                <td><?php echo formatRupeesLakhs((float)$g['target_amount']); ?></td>
                <td class="<?php echo ($g['status'] === 'On Track') ? 'status-on' : 'status-off'; ?>">
                    <?php echo htmlspecialchars($g['status']); ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td><strong>Total</strong></td>
            <td></td>
            <td><?php echo formatRupeesLakhs($totalGoalCurrent); ?></td>
            <td><?php echo 'Rs.' . number_format($totalSip / 1000, 1) . 'k'; ?></td>
            <td><?php echo $totalGoalTarget ? formatRupeesLakhs($totalGoalTarget) : ''; ?></td>
            <td></td>
        </tr>
    </table>

    <h3>3. Appropriate Product Selection at a macro level</h3>
    <table class="report-table small">
        <tr>
            <th>Asset</th>
            <th>Share%</th>
        </tr>
        <?php
        $sumShare = 0;
        foreach ($allocations as $a):
            $sumShare += (float)$a['share_pct'];
            ?>
            <tr>
                <td><?php echo htmlspecialchars($a['asset']); ?></td>
                <td><?php echo number_format((float)$a['share_pct'], 0); ?></td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td><strong>Total</strong></td>
            <td><strong><?php echo number_format($sumShare, 0); ?></strong></td>
        </tr>
    </table>

    <h3>4. Appropriate Scheme Selection</h3>
    <table class="report-table">
        <tr>
            <th colspan="3">Present Schemes</th>
            <th rowspan="2">Action Step</th>
            <th colspan="2">Recommended Schemes</th>
        </tr>
        <tr>
            <th>Scheme Name</th>
            <th>SIP/SWP</th>
            <th>Value as of <?php echo htmlspecialchars($asOn); ?></th>
            <th>Scheme Name</th>
            <th>Amount</th>
        </tr>
        <?php foreach ($schemes as $s): ?>
            <tr>
                <td><?php echo htmlspecialchars($s['scheme_name']); ?></td>
                <td><?php echo (float)$s['sip_swp'] ? number_format((float)$s['sip_swp'], 0) : '0'; ?></td>
                <td><?php echo formatRupeesLakhs((float)$s['current_value']); ?></td>
                <td>
                    <select class="action-dropdown" data-scheme-id="<?php echo (int)$s['id']; ?>">
                        <option value="Continue" <?php echo ($s['action_step'] ?? 'Continue') === 'Continue' ? 'selected' : ''; ?>>Continue</option>
                        <option value="Drop" <?php echo ($s['action_step'] ?? '') === 'Drop' ? 'selected' : ''; ?>>Drop</option>
                        <option value="Switch" <?php echo ($s['action_step'] ?? '') === 'Switch' ? 'selected' : ''; ?>>Switch</option>
                        <option value="Redeem" <?php echo ($s['action_step'] ?? '') === 'Redeem' ? 'selected' : ''; ?>>Redeem</option>
                        <option value="Partially Redeem" <?php echo ($s['action_step'] ?? '') === 'Partially Redeem' ? 'selected' : ''; ?>>Partially Redeem</option>
                    </select>
                </td>
                <td>
                    <input type="text" 
                           class="input-text" 
                           data-scheme-id="<?php echo (int)$s['id']; ?>"
                           data-field="recommended_scheme"
                           value="<?php echo htmlspecialchars($s['recommended_scheme'] ?? ''); ?>"
                           placeholder="Enter scheme name...">
                </td>
                <td>
                    <input type="number" 
                           class="input-text" 
                           data-scheme-id="<?php echo (int)$s['id']; ?>"
                           data-field="recommended_amount"
                           value="<?php echo $s['recommended_amount'] ?? ''; ?>"
                           placeholder="Enter amount..."
                           step="0.01">
                </td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="6">
                <div class="card">
                    <label class="card-title">Rationale</label>
                    <textarea class="large-textarea" data-field="rationale" data-client-id="<?php echo (int)$clientId; ?>"><?php echo htmlspecialchars($rationaleText); ?></textarea>
                </div>
            </td>
        </tr>
    </table>

    <?php if ($annexures): ?>
        <h3>Annexures</h3>
        <ul>
            <?php foreach ($annexures as $ax): ?>
                <li><?php echo htmlspecialchars($ax['line_text']); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

</div>

<div id="toast" class="toast"></div>

<script>
    function showToast(msg) {
        const toast = document.getElementById('toast');
        toast.textContent = msg;
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
        }, 2000);
    }

    // ✅ Auto-save textareas on blur (like Python project)
    document.querySelectorAll('.large-textarea').forEach(function(textarea) {
        textarea.addEventListener('blur', function() {
            const clientId = textarea.getAttribute('data-client-id');
            const field = textarea.getAttribute('data-field');
            const value = textarea.value.trim();

            if (clientId && field) {
                fetch('view_report.php?id=' + encodeURIComponent(clientId), {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    body: new URLSearchParams({
                        ajax: '1',
                        client_id: clientId,
                        field: field,
                        value: value
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast('Saved ' + field);
                    } else {
                        alert('Save failed: ' + (data.error || 'Unknown error'));
                    }
                })
                .catch(err => {
                    console.error('Save error:', err);
                });
            }
        });
    });

    // ✅ Auto-save dropdowns
    document.querySelectorAll('.action-dropdown').forEach(function(select) {
        select.addEventListener('change', function() {
            const schemeId = select.getAttribute('data-scheme-id');
            const value = select.value;

            if (schemeId) {
                fetch('view_report.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    body: new URLSearchParams({
                        ajax_scheme: '1',
                        scheme_id: schemeId,
                        action_step: value
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast('Action step saved');
                    }
                })
                .catch(err => console.error(err));
            }
        });
    });

    document.querySelectorAll('.input-text').forEach(function(input) {
        input.addEventListener('blur', function() {
            const schemeId = input.getAttribute('data-scheme-id');
            const field = input.getAttribute('data-field');
            const value = input.value.trim();

            if (schemeId && field) {
                fetch('view_report.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    body: new URLSearchParams({
                        [field]: value,
                        scheme_id: schemeId,
                        ajax_scheme: '1',
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast('Scheme updated');
                    }
                })
                .catch(err => console.error(err));
            }
        });
    });
</script>

</body>
</html>
