<?php
// client_report.php
// - Upload Excel/PDF
// - Parse + build per-client reports
// - Store everything into DB
// - Inline editable greeting / intro / closing / rationale (AJAX -> DB)
// - File validation, basic auth, duplicate cleanup (same client+as_on), success summary
// - Nav button to view_report.php

require __DIR__ . '/vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use Smalot\PdfParser\Parser as PdfParser;

/* ---------- SIMPLE AUTH (per-file, minimal) ---------- */

session_start();

const ADMIN_USER = 'admin';
const ADMIN_PASS = 'admin123'; // change this

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_user'], $_POST['login_pass'])) {
        if ($_POST['login_user'] === ADMIN_USER && $_POST['login_pass'] === ADMIN_PASS) {
            $_SESSION['logged_in'] = true;
            header('Location: client_report.php');
            exit;
        }
        $login_error = 'Invalid credentials';
    }

    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Login - Client Reports</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            form { max-width: 320px; margin: 0 auto; padding: 20px; border: 1px solid #ccc; border-radius: 6px; }
            label { display: block; margin-top: 10px; }
            input { width: 100%; padding: 6px; margin-top: 4px; }
            button { margin-top: 15px; padding: 8px 16px; }
            .error { color: #b30000; margin-top: 10px; }
        </style>
    </head>
    <body>
    <h1>Client Reports Login</h1>
    <form method="post">
        <label>Username
            <input type="text" name="login_user" required>
        </label>
        <label>Password
            <input type="password" name="login_pass" required>
        </label>
        <button type="submit">Login</button>
        <?php if (!empty($login_error)): ?>
            <div class="error"><?php echo htmlspecialchars($login_error); ?></div>
        <?php endif; ?>
    </form>
    </body>
    </html>
    <?php
    exit;
}

/* ---------- DATABASE CONFIG ---------- */

const DB_HOST = 'localhost';
const DB_NAME = 'client_reports';
const DB_USER = 'root';
const DB_PASS = ''; // your password

function getPdo(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        ]);
    }
    return $pdo;
}

/* ---------- CONFIG: DEFAULT TEXTS (fallbacks only) ---------- */

$DEFAULT_GREETING  = 'Dear Mr.';
$DEFAULT_INTRO     = "Introduction";
$DEFAULT_CLOSING   = "Closing remarks";
$DEFAULT_RATIONALE = "Rationale for recommendations";

/* ---------- GENERIC HELPERS ---------- */

function normalize_label(string $label): string {
    $label = strtolower($label);
    $label = preg_replace('/[^a-z0-9]+/', ' ', $label);
    return trim($label);
}

function findColumnByKeywords(array $headerRow, array $keywords) {
    $normKeywords = array_map('normalize_label', $keywords);
    foreach ($headerRow as $col => $labelRaw) {
        $label = normalize_label((string)$labelRaw);
        foreach ($normKeywords as $kw) {
            if ($kw !== '' && strpos($label, $kw) !== false) {
                return $col;
            }
        }
    }
    return null;
}

function findHeaderRowForPV(array $rows): ?int {
    $maxScan = min(40, count($rows));
    for ($i = 0; $i < $maxScan; $i++) {
        if (!isset($rows[$i]) || !is_array($rows[$i])) continue;
        $row       = $rows[$i];
        $colScheme = findColumnByKeywords($row, ['scheme name', 'scheme']);
        $colCurr   = findColumnByKeywords($row, ['current value', 'current']);
        if ($colScheme !== null && $colCurr !== null) {
            return $i;
        }
    }
    return null;
}

function findHeaderRowGeneric(array $rows, array $mustKeywords): ?int {
    $maxScan = min(40, count($rows));
    for ($i = 0; $i < $maxScan; $i++) {
        if (!isset($rows[$i]) || !is_array($rows[$i])) continue;
        $row = $rows[$i];
        $ok  = true;
        foreach ($mustKeywords as $kwList) {
            if (findColumnByKeywords($row, $kwList) === null) {
                $ok = false;
                break;
            }
        }
        if ($ok) return $i;
    }
    return null;
}

function parseIndianNumber(string $s): float {
    $s = preg_replace('/[^\d\.\-]/', '', $s);
    if ($s === '' || $s === '-' || $s === '--') return 0.0;
    return (float)$s;
}

function formatRupeesLakhs(float $amount, bool $lakhs = true): string {
    if ($lakhs) {
        $v = $amount / 100000;
        return 'Rs.' . number_format($v, 2) . ' lakhs';
    }
    return 'Rs.' . number_format($amount, 2);
}

function formatPercent(float $v): string {
    return number_format($v, 2) . '%';
}

function clientNameFromFilename(string $path): ?string {
    $base = basename($path);
    $base = preg_replace('/\.(xlsx|xls|csv|pdf)$/i', '', $base);

    if (preg_match('/PortfolioValuation-([^-]+)-/i', $base, $m)) {
        return trim($m[1]);
    }
    if (preg_match('/Portfolio Summary-([^-]+)-/i', $base, $m)) {
        return trim($m[1]);
    }
    if (preg_match('/Allocation Analysis-([^-]+)-/i', $base, $m)) {
        return trim($m[1]);
    }
    if (preg_match('/GoalStatusReport_([^_]+)_/i', $base, $m)) {
        return trim(str_replace('_', ' ', $m[1]));
    }
    return null;
}

function filterClientArrayForTarget(array $dataset, ?string $targetName): array {
    if (empty($dataset) || !$targetName) return $dataset;

    if (isset($dataset[$targetName])) {
        return [$targetName => $dataset[$targetName]];
    }

    if (count($dataset) === 1) {
        $onlyKey = array_key_first($dataset);
        return [$targetName => $dataset[$onlyKey]];
    }

    if (isset($dataset['Client'])) {
        return [$targetName => $dataset['Client']];
    }

    return $dataset;
}

/* ---------- PARSERS (same as before) ---------- */
/* (omitted comments for brevity, code identical logic-wise) */

function parsePortfolioValuation(string $path): array {
    $spreadsheet = IOFactory::load($path);
    $sheet = $spreadsheet->getSheetByName('1. Mutual Fund') ?? $spreadsheet->getSheet(0);
    $rows = $sheet->toArray(null, true, true, true);
    if (!$rows) return [];
    $rows = array_values($rows);

    $headerIndex = findHeaderRowForPV($rows);
    if ($headerIndex === null || !isset($rows[$headerIndex]) || !is_array($rows[$headerIndex])) {
        return [];
    }

    $headerRow = $rows[$headerIndex];
    $dataRows  = array_slice($rows, $headerIndex + 1);

    $colScheme   = findColumnByKeywords($headerRow, ['scheme name', 'scheme']);
    $colPurchase = findColumnByKeywords($headerRow, ['purchase value', 'cost value', 'invested', 'cost']);
    $colCurrent  = findColumnByKeywords($headerRow, ['current value', 'current']);
    $colCagr     = findColumnByKeywords($headerRow, ['cagr']);
    $colXirr     = findColumnByKeywords($headerRow, ['xirr']);
    $colClient   = findColumnByKeywords($headerRow, ['investor name', 'client name', 'holder']);

    $fallbackClient = clientNameFromFilename($path) ?? 'Client';
    $data           = [];
    $grandTotals    = [];

    foreach ($dataRows as $row) {
        if (!is_array($row)) continue;

        $scheme = $colScheme !== null ? trim((string)$row[$colScheme]) : '';
        if ($scheme === '') continue;

        $normScheme = strtolower(trim(preg_replace('/\s+/', ' ', $scheme)));
        $client     = $colClient !== null ? trim((string)$row[$colClient]) : $fallbackClient;

        if (preg_match('/\([A-Z0-9]{10}\)/', $scheme)) {
            continue;
        }

        $purchase = $colPurchase !== null ? parseIndianNumber((string)$row[$colPurchase]) : 0.0;
        $current  = $colCurrent  !== null ? parseIndianNumber((string)$row[$colCurrent])  : 0.0;
        $cagr     = $colCagr     !== null ? (float)str_replace(['%', ','], '', (string)$row[$colCagr]) : 0.0;
        $xirr     = $colXirr     !== null ? (float)str_replace(['%', ','], '', (string)$row[$colXirr]) : 0.0;

        if (strpos($normScheme, 'grand total') !== false) {
            $grandTotals[$client] = [
                'current' => $current,
                'cagr'    => $cagr,
            ];
            continue;
        }

        if (strpos($normScheme, 'total') !== false ||
            $normScheme === 'equity' ||
            $normScheme === 'hybrid') {
            continue;
        }

        if (!isset($data[$client])) {
            $data[$client] = [
                'schemes' => [],
                'totals'  => [
                    'purchase' => 0,
                    'current'  => 0,
                    'profit'   => 0,
                    'cagr_sum' => 0,
                    'xirr_sum' => 0,
                ]
            ];
        }

        $data[$client]['schemes'][$scheme] = [
            'scheme'         => $scheme,
            'purchase_value' => $purchase,
            'current_value'  => $current,
            'cagr'           => $cagr,
            'xirr'           => $xirr,
        ];

        $data[$client]['totals']['purchase'] += $purchase;
        $data[$client]['totals']['current']  += $current;
        $data[$client]['totals']['profit']   += ($current - $purchase);
        $data[$client]['totals']['cagr_sum'] += $cagr * $current;
        $data[$client]['totals']['xirr_sum'] += $xirr * $current;
    }

    foreach ($data as $client => &$info) {
        $cur = max($info['totals']['current'], 1);
        $info['totals']['cagr_weighted'] = $info['totals']['cagr_sum'] / $cur;
        $info['totals']['xirr_weighted'] = $info['totals']['xirr_sum'] / $cur;

        if (isset($grandTotals[$client])) {
            $info['totals']['current']       = $grandTotals[$client]['current'];
            $info['totals']['cagr_weighted'] = $grandTotals[$client]['cagr'];
        }
    }

    return $data;
}

function parseAllocationAnalysis(string $path): array {
    $spreadsheet = IOFactory::load($path);
    $client      = clientNameFromFilename($path) ?? 'Client';

    $equityPct = null;
    $debtPct   = null;

    foreach ($spreadsheet->getWorksheetIterator() as $sheet) {
        $rows = $sheet->toArray(null, true, true, true);
        if (!$rows) continue;
        $rows = array_values($rows);

        $headerIndex = findHeaderRowGeneric($rows, [
            ['scheme name'],
            ['equity'],
            ['debt'],
            ['gold'],
            ['global equity'],
            ['total']
        ]);
        if ($headerIndex === null || !isset($rows[$headerIndex]) || !is_array($rows[$headerIndex])) {
            continue;
        }

        $headerRow = $rows[$headerIndex];
        $dataRows  = array_slice($rows, $headerIndex + 1);

        $colScheme = findColumnByKeywords($headerRow, ['scheme name']);
        $colEquity = findColumnByKeywords($headerRow, ['equity']);
        $colDebt   = findColumnByKeywords($headerRow, ['debt']);
        $colGold   = findColumnByKeywords($headerRow, ['gold']);
        $colGlobal = findColumnByKeywords($headerRow, ['global equity']);
        $colTotal  = findColumnByKeywords($headerRow, ['total']);

        $eqAmt = $debtAmt = $goldAmt = $globalAmt = $totalAmt = 0.0;

        foreach ($dataRows as $row) {
            if (!is_array($row)) continue;

            $schemeName = $colScheme !== null ? trim((string)$row[$colScheme]) : '';
            $norm       = strtolower(trim($schemeName));

            if (strpos($norm, 'grand total') !== false) {
                $eqAmt     = $colEquity !== null ? parseIndianNumber((string)$row[$colEquity]) : 0.0;
                $debtAmt   = $colDebt   !== null ? parseIndianNumber((string)$row[$colDebt])   : 0.0;
                $goldAmt   = $colGold   !== null ? parseIndianNumber((string)$row[$colGold])   : 0.0;
                $globalAmt = $colGlobal !== null ? parseIndianNumber((string)$row[$colGlobal]) : 0.0;
                $totalAmt  = $colTotal  !== null ? parseIndianNumber((string)$row[$colTotal])  : 0.0;
                break;
            }
        }

        if ($totalAmt > 0) {
            $equityAmt = $eqAmt + $goldAmt + $globalAmt;
            $equityPct = ($equityAmt / $totalAmt) * 100.0;
            $debtPct   = ($debtAmt   / $totalAmt) * 100.0;
            break;
        }
    }

    $data = [];
    $data[$client] = ['asset_allocation' => []];

    if ($equityPct !== null) {
        $data[$client]['asset_allocation']['Equity'] = $equityPct;
    }
    if ($debtPct !== null) {
        $data[$client]['asset_allocation']['Debt']   = $debtPct;
    }

    return $data;
}

function parseRunningSystematicTransactions(string $path): array {
    $spreadsheet = IOFactory::load($path);
    $sheet       = $spreadsheet->getSheet(0);
    $rows        = $sheet->toArray(null, true, true, true);
    if (!$rows) return [];
    $rows = array_values($rows);

    $headerIndex = findHeaderRowGeneric($rows, [
        ['scheme name', 'scheme'],
        ['installment', 'amount']
    ]);
    if ($headerIndex === null || !isset($rows[$headerIndex]) || !is_array($rows[$headerIndex])) {
        return [];
    }

    $headerRow = $rows[$headerIndex];
    $dataRows  = array_slice($rows, $headerIndex + 1);

    $colClient = findColumnByKeywords($headerRow, ['investor name', 'client name', 'holder']);
    $colScheme = findColumnByKeywords($headerRow, ['scheme name', 'scheme']);
    $colType   = findColumnByKeywords($headerRow, ['txn type', 'transaction type', 'type']);
    $colAmt    = findColumnByKeywords($headerRow, ['installment', 'amount']);

    $fallbackClient = clientNameFromFilename($path) ?? 'Client';
    $data           = [];

    foreach ($dataRows as $row) {
        if (!is_array($row)) continue;

        $scheme = $colScheme !== null ? trim((string)$row[$colScheme]) : '';
        if ($scheme === '') continue;

        $client = $colClient !== null ? trim((string)$row[$colClient]) : $fallbackClient;
        $amount = $colAmt    !== null ? parseIndianNumber((string)$row[$colAmt]) : 0.0;
        if ($amount == 0) continue;

        $type = $colType !== null ? strtoupper(trim((string)$row[$colType])) : 'SIP';

        if (!isset($data[$client])) $data[$client] = [];
        if (!isset($data[$client][$scheme])) $data[$client][$scheme] = 0;
        $data[$client][$scheme] += $amount;
    }

    return $data;
}

function parsePortfolioSummary(string $path): array {
    $spreadsheet = IOFactory::load($path);
    $sheet       = $spreadsheet->getSheet(0);
    $rows        = $sheet->toArray(null, true, true, true);
    if (!$rows) return [];
    $rows = array_values($rows);

    $headerIndex = findHeaderRowGeneric($rows, [
        ['unrealised gain', 'unrealized gain'],
        ['realised gain', 'realized gain'],
        ['xirr']
    ]);
    if ($headerIndex === null || !isset($rows[$headerIndex]) || !is_array($rows[$headerIndex])) {
        return [];
    }

    $headerRow = $rows[$headerIndex];
    $dataRows  = array_slice($rows, $headerIndex + 1);

    $colTotal  = findColumnByKeywords($headerRow, ['current value', 'total current value', 'portfolio value', 'market value', 'value']);
    $colUnreal = findColumnByKeywords($headerRow, ['unrealised gain', 'unrealized gain']);
    $colReal   = findColumnByKeywords($headerRow, ['realised gain', 'realized gain']);
    $colXirr   = findColumnByKeywords($headerRow, ['xirr']);

    $client = clientNameFromFilename($path) ?? 'Client';
    $best   = null;

    foreach ($dataRows as $row) {
        if (!is_array($row)) continue;

        $total  = $colTotal  !== null ? parseIndianNumber((string)($row[$colTotal]  ?? '')) : 0.0;
        $unreal = $colUnreal !== null ? parseIndianNumber((string)($row[$colUnreal] ?? '')) : 0.0;
        $real   = $colReal   !== null ? parseIndianNumber((string)($row[$colReal]   ?? '')) : 0.0;
        $xirr   = $colXirr   !== null ? (float)str_replace(['%', ','], '', (string)($row[$colXirr] ?? '')) : 0.0;

        if ($total == 0 && $unreal == 0 && $real == 0 && $xirr == 0) continue;

        $isGrand = false;
        foreach ($row as $cellVal) {
            $cellStr = strtolower((string)$cellVal);
            if (strpos($cellStr, 'grand total') !== false || $cellStr === 'total') {
                $isGrand = true;
                break;
            }
        }

        $record = [
            'total_amount' => $total,
            'profit'       => $unreal + $real,
            'cagr'         => 0.0,
            'xirr'         => $xirr,
        ];

        if ($isGrand) {
            $best = $record;
            break;
        }
        if ($best === null) $best = $record;
    }

    $data = [];
    if ($best !== null) {
        $data[$client] = $best;
    }
    return $data;
}

function parseGoalStatusPdf(string $path): array {
    $parser = new PdfParser();
    $pdf    = $parser->parseFile($path);
    $text   = $pdf->getText();

    $clientName = clientNameFromFilename($path) ?? '';

    $asOn = '';
    if (preg_match('/As on\s+([\d\/-]+)/', $text, $mDate)) {
        $asOn = trim($mDate[1]);
    }

    $goals = [];

    if (preg_match('/Goal Summary.*?Options to meet shortfall(.*?)Total\s*:/s', $text, $mSection)) {
        $goalBlock = trim($mSection[1]);
        $lines     = preg_split('/\r\n|\r|\n/', $goalBlock);

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || stripos($line, 'Goal Date') !== false) continue;

            $lineNorm = preg_replace('/\s+/', ' ', $line);
            $parts    = explode(' ', $lineNorm);

            $goalDatePos = null;
            foreach ($parts as $i => $p) {
                if (preg_match('/\d{2}-[A-Za-z]{3}-\d{4}/', $p)) {
                    $goalDatePos = $i;
                    break;
                }
            }
            if ($goalDatePos === null) continue;

            $goalName = trim(implode(' ', array_slice($parts, 0, $goalDatePos)));
            $goalDate = $parts[$goalDatePos];

            $rest = array_slice($parts, $goalDatePos + 2);
            if (count($rest) < 5) continue;

            $targetAmount = parseIndianNumber($rest[0] ?? '0');
            $completion   = (float)str_replace(['%', ','], '', $rest[1] ?? '0');
            $currentValue = parseIndianNumber($rest[2] ?? '0');
            $runningSip   = parseIndianNumber($rest[3] ?? '0');
            $projected    = parseIndianNumber($rest[4] ?? '0');

            $status = ($completion >= 70) ? 'On Track' : 'Needs Attention';

            $goals[] = [
                'goal'          => $goalName,
                'goal_date'     => $goalDate,
                'target_amount' => $targetAmount,
                'current_value' => $currentValue,
                'running_sip'   => $runningSip,
                'projected'     => $projected,
                'completion'    => $completion,
                'status'        => $status,
            ];
        }
    }

    return [
        'client_name' => $clientName,
        'as_on'       => $asOn,
        'goals'       => $goals,
    ];
}

/* ---------- MERGING ---------- */

function buildClientReports(array $pv, array $aa, array $rst, array $ps, array $pdfGoal): array {
    $clients    = [];
    $targetName = $pdfGoal['client_name'] ?? null;

    if ($targetName) {
        $pv  = filterClientArrayForTarget($pv,  $targetName);
        $aa  = filterClientArrayForTarget($aa,  $targetName);
        $rst = filterClientArrayForTarget($rst, $targetName);
        $ps  = filterClientArrayForTarget($ps,  $targetName);
    }

    foreach ($pv as $client => $info) {
        if (!isset($clients[$client])) {
            $clients[$client] = [
                'name'       => $client,
                'current'    => [],
                'goals'      => [],
                'allocation' => [],
                'schemes'    => [],
                'as_on'      => '',
            ];
        }
        $clients[$client]['schemes']           = $info['schemes'];
        $clients[$client]['current']['totals'] = $info['totals'];
    }

    foreach ($aa as $client => $info) {
        if (!isset($clients[$client])) {
            $clients[$client] = [
                'name'       => $client,
                'current'    => [],
                'goals'      => [],
                'allocation' => [],
                'schemes'    => [],
                'as_on'      => '',
            ];
        }
        $clients[$client]['allocation'] = $info['asset_allocation'];
    }

    foreach ($rst as $client => $schemes) {
        if (!isset($clients[$client])) {
            $clients[$client] = [
                'name'       => $client,
                'current'    => [],
                'goals'      => [],
                'allocation' => [],
                'schemes'    => [],
                'as_on'      => '',
            ];
        }
        foreach ($schemes as $schemeName => $amount) {
            if (!isset($clients[$client]['schemes'][$schemeName])) {
                $clients[$client]['schemes'][$schemeName] = [
                    'scheme'         => $schemeName,
                    'purchase_value' => 0,
                    'current_value'  => 0,
                    'cagr'           => 0,
                    'xirr'           => 0,
                ];
            }
            $clients[$client]['schemes'][$schemeName]['sip_swp'] = $amount;
        }
    }

    foreach ($ps as $client => $summary) {
        if (!isset($clients[$client])) {
            $clients[$client] = [
                'name'       => $client,
                'current'    => [],
                'goals'      => [],
                'allocation' => [],
                'schemes'    => [],
                'as_on'      => '',
            ];
        }
        $clients[$client]['current']['summary'] = $summary;
    }

    if (!empty($pdfGoal['client_name'])) {
        $cName = $pdfGoal['client_name'];
        if (!isset($clients[$cName])) {
            $clients[$cName] = [
                'name'       => $cName,
                'current'    => [],
                'goals'      => [],
                'allocation' => [],
                'schemes'    => [],
                'as_on'      => '',
            ];
        }
        $clients[$cName]['goals'] = $pdfGoal['goals'];
        $clients[$cName]['as_on'] = $pdfGoal['as_on'];
        $clients[$cName]['name']  = $cName;
    }

    return $clients;
}

/* ---------- RENDER SINGLE CLIENT REPORT ---------- */

function renderClientReport(
    array $clientData,
    string $greetingBase,
    string $introText,
    string $closingText,
    string $rationaleText,
    array $annexureLines,
    int $clientId
) {
    global $DEFAULT_GREETING, $DEFAULT_INTRO, $DEFAULT_CLOSING, $DEFAULT_RATIONALE;

    $name       = $clientData['name'];
    $asOn       = $clientData['as_on'] ?? '';
    $allocation = $clientData['allocation'] ?? [];
    $schemes    = $clientData['schemes'] ?? [];
    $goals      = $clientData['goals'] ?? [];

    $totals  = $clientData['current']['totals'] ?? ['purchase'=>0,'current'=>0,'profit'=>0,'cagr_weighted'=>0,'xirr_weighted'=>0];
    $summary = $clientData['current']['summary'] ?? null;

    $totalAmount = $totals['current'];
    $profit      = $summary['profit'] ?? $totals['profit'];
    $cagr        = $totals['cagr_weighted'];
    $xirr        = $summary['xirr'] ?? $totals['xirr_weighted'];

    $totalSip = 0;
    foreach ($goals as $g) {
        $totalSip += $g['running_sip'] ?? 0;
    }

    $totalGoalCurrent = 0;
    $totalGoalTarget  = 0;
    foreach ($goals as $g) {
        $totalGoalCurrent += $g['current_value'];
        $totalGoalTarget  += $g['target_amount'];
    }

    if (trim($introText)     === '') $introText     = $DEFAULT_INTRO;
    if (trim($closingText)   === '') $closingText   = $DEFAULT_CLOSING;
    if (trim($rationaleText) === '') $rationaleText = $DEFAULT_RATIONALE;

    $base = trim($greetingBase);
    if ($base === '') $base = $DEFAULT_GREETING;
    $fullGreeting = rtrim($base) . ' ' . $name . ',';

    ?>
    <div class="client-report" data-client-id="<?php echo (int)$clientId; ?>">

        <div class="editable-block">
            <span class="editable-text" data-field="greeting"><?php echo htmlspecialchars($fullGreeting); ?></span>
            <button type="button" class="edit-btn">Edit</button>
        </div>

        <div class="editable-block">
            <span class="editable-text" data-field="intro"><?php echo nl2br(htmlspecialchars($introText)); ?></span>
            <button type="button" class="edit-btn">Edit</button>
        </div>

        <div class="editable-block">
            <span class="editable-text" data-field="closing"><?php echo nl2br(htmlspecialchars($closingText)); ?></span>
            <button type="button" class="edit-btn">Edit</button>
        </div>

        <h3>1. Current Situation</h3>
        <table class="report-table">
            <tr><th colspan="2">Current Situation</th></tr>
            <tr>
                <td>Total Amount as of <?php echo htmlspecialchars($asOn); ?></td>
                <td><?php echo formatRupeesLakhs($totalAmount); ?></td>
            </tr>
            <tr>
                <td>CAGR of current schemes</td>
                <td><?php echo formatPercent($cagr); ?></td>
            </tr>
            <?php if ($xirr != 0): ?>
                <tr>
                    <td>XIRR of all schemes since inception</td>
                    <td><?php echo formatPercent($xirr); ?></td>
                </tr>
            <?php endif; ?>
            <tr>
                <td>Profit since inception</td>
                <td><?php echo formatRupeesLakhs($profit); ?></td>
            </tr>
        </table>

        <h3>2. Objectives Progress for guiding on appropriate schemes</h3>
        <table class="report-table">
            <tr>
                <th>Goal/s</th>
                <th>Target Year</th>
                <th>Current Amount (Rs)</th>
                <th>SIP/SWP</th>
                <th>Target Amount (Rs)</th>
                <th>Status</th>
            </tr>
            <?php foreach ($goals as $g): ?>
                <tr>
                    <td><?php echo htmlspecialchars($g['goal']); ?></td>
                    <td><?php echo htmlspecialchars(substr($g['goal_date'], -4)); ?></td>
                    <td><?php echo formatRupeesLakhs($g['current_value']); ?></td>
                    <td><?php echo 'Rs.' . number_format(($g['running_sip'] ?? 0) / 1000, 1) . 'k'; ?></td>
                    <td><?php echo formatRupeesLakhs($g['target_amount']); ?></td>
                    <td class="<?php echo $g['status'] === 'On Track' ? 'status-on' : 'status-off'; ?>">
                        <?php echo htmlspecialchars($g['status']); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td><strong>Total</strong></td>
                <td></td>
                <td><?php echo formatRupeesLakhs($totalGoalCurrent); ?></td>
                <td><?php echo 'Rs.' . number_format($totalSip / 1000, 1) . 'k'; ?></td>
                <td><?php echo $totalGoalTarget ? formatRupeesLakhs($totalGoalTarget) : ''; ?></td>
                <td></td>
            </tr>
        </table>

        <h3>3. Appropriate Product Selection at a macro level</h3>
        <table class="report-table small">
            <tr>
                <th>Asset</th>
                <th>Share%</th>
            </tr>
            <?php
            $sumShare = 0;
            foreach ($allocation as $asset => $share):
                $sumShare += $share;
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($asset); ?></td>
                    <td><?php echo number_format($share, 0); ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td><strong>Total</strong></td>
                <td><strong><?php echo number_format($sumShare, 0); ?></strong></td>
            </tr>
        </table>

        <h3>4. Appropriate Scheme Selection</h3>
        <table class="report-table">
            <tr>
                <th colspan="3">Present Schemes</th>
                <th rowspan="2">Action Step</th>
                <th colspan="2">Recommended Schemes</th>
            </tr>
            <tr>
                <th>Scheme Name</th>
                <th>SIP/SWP</th>
                <th>Value as of <?php echo htmlspecialchars($asOn); ?></th>
                <th>Scheme Name</th>
                <th>Amount</th>
            </tr>
            <?php foreach ($schemes as $s): ?>
                <tr>
                    <td><?php echo htmlspecialchars($s['scheme']); ?></td>
                    <td><?php echo !empty($s['sip_swp']) ? number_format($s['sip_swp'], 0) : '0'; ?></td>
                    <td><?php echo formatRupeesLakhs((float)$s['current_value']); ?></td>
                    <td>
                        <select class="action-dropdown">
                            <option value="Continue" selected>Continue</option>
                            <option value="Drop">Drop</option>
                            <option value="Switch">Switch</option>
                            <option value="Redeem">Redeem</option>
                            <option value="Partially Redeem">Partially Redeem</option>
                        </select>
                    </td>
                    <td></td>
                    <td></td>
                </tr>
            <?php endforeach; ?>

            <tr>
                <td colspan="6">
                    <strong>Rationale</strong>
                    <div class="editable-block inline">
                        <span class="editable-text" data-field="rationale"><?php echo nl2br(htmlspecialchars($rationaleText)); ?></span>
                        <button type="button" class="edit-btn">Edit</button>
                    </div>
                </td>
            </tr>
        </table>

        <?php if (!empty($annexureLines)): ?>
            <h3>Annexures</h3>
            <ul>
                <?php foreach ($annexureLines as $line):
                    $line = trim($line);
                    if ($line === '') continue;
                    ?>
                    <li><?php echo htmlspecialchars($line); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
    <?php
}

/* ---------- AJAX HANDLER FOR INLINE EDITS ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === '1') {
    header('Content-Type: application/json');

    try {
        $pdo      = getPdo();
        $clientId = (int)($_POST['client_id'] ?? 0);
        $field    = $_POST['field'] ?? '';
        $value    = $_POST['value'] ?? '';

        if (!$clientId || !in_array($field, ['greeting','intro','closing','rationale'], true)) {
            throw new Exception('Invalid input');
        }

        switch ($field) {
            case 'greeting':
                $column = 'greeting_prefix';
                break;
            case 'intro':
                $column = 'intro_text';
                break;
            case 'closing':
                $column = 'closing_text';
                break;
            case 'rationale':
                $column = 'rationale_text';
                break;
            default:
                throw new Exception('Unknown field');
        }

        $sql = "UPDATE clients SET {$column} = :val WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':val' => $value,
            ':id'  => $clientId,
        ]);

        echo json_encode(['success' => true]);
    } catch (Throwable $e) {
        echo json_encode([
            'success' => false,
            'error'   => $e->getMessage(),
        ]);
    }
    exit;
}

/* ---------- MAIN CONTROLLER ---------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['ajax'])) {

    global $DEFAULT_GREETING, $DEFAULT_INTRO, $DEFAULT_CLOSING, $DEFAULT_RATIONALE;

    $greetingBase  = $_POST['greeting']       ?? $DEFAULT_GREETING;
    $introText     = $_POST['intro_text']     ?? $DEFAULT_INTRO;
    $closingText   = $_POST['closing_text']   ?? $DEFAULT_CLOSING;
    $rationaleText = $_POST['rationale_text'] ?? $DEFAULT_RATIONALE;

    $uploadDir = __DIR__ . '/uploads';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    $allowedExt = ['xlsx','xls','pdf'];
    $maxFileSize = 10 * 1024 * 1024; // 10MB

    $pvFiles  = [];
    $aaFiles  = [];
    $rstFiles = [];
    $psFiles  = [];
    $pdfFiles = [];
    $fileErrors = [];

    try {
        foreach ($_FILES['client_files']['name'] as $i => $name) {
            if ($_FILES['client_files']['error'][$i] !== UPLOAD_ERR_OK) {
                $fileErrors[] = "Error uploading file: " . htmlspecialchars($name);
                continue;
            }

            $size = $_FILES['client_files']['size'][$i];
            if ($size > $maxFileSize) {
                $fileErrors[] = "File too large (max 10MB): " . htmlspecialchars($name);
                continue;
            }

            $tmp    = $_FILES['client_files']['tmp_name'][$i];
            $ext    = strtolower(pathinfo($name, PATHINFO_EXTENSION));

            if (!in_array($ext, $allowedExt, true)) {
                $fileErrors[] = "Unsupported file type: " . htmlspecialchars($name);
                continue;
            }

            $target = $uploadDir . '/' . uniqid() . '_' . basename($name);
            if (!move_uploaded_file($tmp, $target)) {
                $fileErrors[] = "Failed to move uploaded file: " . htmlspecialchars($name);
                continue;
            }

            if ($ext === 'xlsx' || $ext === 'xls') {
                if (stripos($name, 'PortfolioValuation') !== false) {
                    $pvFiles[] = $target;
                } elseif (stripos($name, 'Allocation Analysis') !== false || stripos($name, 'Allocation_Analysis') !== false) {
                    $aaFiles[] = $target;
                } elseif (stripos($name, 'Running Systematic Transactions') !== false) {
                    $rstFiles[] = $target;
                } elseif (stripos($name, 'Portfolio Summary') !== false) {
                    $psFiles[] = $target;
                }
            } elseif ($ext === 'pdf' && stripos($name, 'GoalStatusReport') !== false) {
                $pdfFiles[] = $target;
            }
        }

        $pvAll = [];
        foreach ($pvFiles as $f) {
            $tmp   = parsePortfolioValuation($f);
            $pvAll = array_replace_recursive($pvAll, $tmp);
        }

        $aaAll = [];
        foreach ($aaFiles as $f) {
            $tmp   = parseAllocationAnalysis($f);
            $aaAll = array_replace_recursive($aaAll, $tmp);
        }

        $rstAll = [];
        foreach ($rstFiles as $f) {
            $tmp = parseRunningSystematicTransactions($f);
            foreach ($tmp as $client => $schemes) {
                if (!isset($rstAll[$client])) $rstAll[$client] = [];
                foreach ($schemes as $scheme => $amt) {
                    if (!isset($rstAll[$client][$scheme])) $rstAll[$client][$scheme] = 0;
                    $rstAll[$client][$scheme] += $amt;
                }
            }
        }

        $psAll = [];
        foreach ($psFiles as $f) {
            $tmp   = parsePortfolioSummary($f);
            $psAll = array_replace_recursive($psAll, $tmp);
        }

        $allClientReports = [];
        $validClientNames = [];

        if ($pdfFiles) {
            foreach ($pdfFiles as $pdfFile) {
                $pdfGoal = parseGoalStatusPdf($pdfFile);
                if (!empty($pdfGoal['client_name'])) {
                    $validClientNames[] = $pdfGoal['client_name'];
                }
                $reports = buildClientReports($pvAll, $aaAll, $rstAll, $psAll, $pdfGoal);
                $allClientReports = array_replace_recursive($allClientReports, $reports);
            }
        } else {
            $reports = buildClientReports($pvAll, $aaAll, $rstAll, $psAll, ['client_name'=>'','as_on'=>'','goals'=>[]]);
            $allClientReports = array_replace_recursive($allClientReports, $reports);
        }

        $validSet = array_flip($validClientNames);

        $pdo = getPdo();

        $stmtClient = $pdo->prepare("
            INSERT INTO clients
                (name, as_on, total_amount, profit, cagr, xirr,
                 total_goal_current, total_goal_target, total_sip,
                 greeting_prefix, intro_text, closing_text, rationale_text)
            VALUES
                (:name, :as_on, :total_amount, :profit, :cagr, :xirr,
                 :total_goal_current, :total_goal_target, :total_sip,
                 :greeting_prefix, :intro_text, :closing_text, :rationale_text)
        ");

        $stmtGoal = $pdo->prepare("
            INSERT INTO client_goals
                (client_id, goal, goal_date, current_amount, sip_swp,
                 target_amount, projected, completion, status)
            VALUES
                (:client_id, :goal, :goal_date, :current_amount, :sip_swp,
                 :target_amount, :projected, :completion, :status)
        ");

        $stmtAlloc = $pdo->prepare("
            INSERT INTO client_allocations
                (client_id, asset, share_pct)
            VALUES
                (:client_id, :asset, :share_pct)
        ");

        $stmtScheme = $pdo->prepare("
            INSERT INTO client_schemes
                (client_id, scheme_name, sip_swp, current_value,
                 action_step, recommended_scheme, recommended_amount)
            VALUES
                (:client_id, :scheme_name, :sip_swp, :current_value,
                 :action_step, :recommended_scheme, :recommended_amount)
        ");

        $stmtAnnex = $pdo->prepare("
            INSERT INTO client_annexures
                (client_id, line_text)
            VALUES
                (:client_id, :line_text)
        ");

        $savedCount = 0;

        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Client Goal & Portfolio Summary</title>
            
            <!-- Modern Fonts -->
            <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
            
            <!-- Modern Styling -->
            <link rel="stylesheet" href="public/css/styles.css">
            
            <style>
                /* Additional specific styles */
                .report-table {
                    width: 70%;
                    margin: 0 auto 20px 0;
                }
                .report-table.small {
                    width: 40%;
                }
                
                .client-report {
                    page-break-after: always;
                }
                
                .editable-block {
                    padding-right: 50px;
                }
                
                .editable-block.inline {
                    display: inline-block;
                    width: 100%;
                    padding-right: 60px;
                }
                
                .edit-btn {
                    position: absolute;
                    right: 0;
                    bottom: 0;
                }
            </style>
        </head>
        <body>

        <div class="nav-bar">
            <a href="client_report.php" class="nav-button">Upload New Files</a>
            <a href="view_report.php" class="nav-button">View Saved Reports</a>
            <button onclick="window.print()" class="nav-button" type="button">Print</button>
        </div>

        <?php if ($fileErrors): ?>
            <div class="flash flash-error">
                <?php foreach ($fileErrors as $err) {
                    echo htmlspecialchars($err) . '<br>';
                } ?>
            </div>
        <?php endif; ?>

        <?php
        if (!$allClientReports) {
            echo "<div class='flash flash-error'>No client data could be extracted. Please check that the correct files were uploaded.</div>";
        } else {
            foreach ($allClientReports as $client => $data) {
                if (!empty($validSet) && !isset($validSet[$data['name']])) continue;

                $name       = $data['name'];
                $asOn       = $data['as_on'] ?? '';
                $allocation = $data['allocation'] ?? [];
                $schemes    = $data['schemes'] ?? [];
                $goals      = $data['goals'] ?? [];

                $totals  = $data['current']['totals'] ?? [
                    'purchase'      => 0,
                    'current'       => 0,
                    'profit'        => 0,
                    'cagr_weighted' => 0,
                    'xirr_weighted' => 0
                ];
                $summary = $data['current']['summary'] ?? null;

                $totalAmount = $totals['current'];
                $profit      = $summary['profit'] ?? $totals['profit'];
                $cagr        = $totals['cagr_weighted'];
                $xirr        = $summary['xirr'] ?? $totals['xirr_weighted'];

                $totalSip         = 0;
                $totalGoalCurrent = 0;
                $totalGoalTarget  = 0;
                foreach ($goals as $g) {
                    $totalSip         += $g['running_sip']   ?? 0;
                    $totalGoalCurrent += $g['current_value'] ?? 0;
                    $totalGoalTarget  += $g['target_amount'] ?? 0;
                }

                if ($asOn !== '') {
                    $annexureLinesForClient = [
                        "PDF document showing portfolio performance from inception including redeemed schemes reported on : " . $asOn,
                        "Current portfolio reported on : " . $asOn,
                        "Goal report reported on : " . $asOn,
                    ];
                } else {
                    $annexureLinesForClient = [];
                }

                // --- DUPLICATE CLEANUP: remove existing rows for same name + as_on ---
                if ($asOn !== '') {
                    $delStmt = $pdo->prepare("DELETE FROM clients WHERE name = :name AND as_on = :as_on");
                    $delStmt->execute([':name' => $name, ':as_on' => $AsOn]);
                }

                // ----- SAVE MASTER ROW -----
                $stmtClient->execute([
                    ':name'               => $name,
                    ':as_on'              => $asOn,
                    ':total_amount'       => $totalAmount,
                    ':profit'             => $profit,
                    ':cagr'               => $cagr,
                    ':xirr'               => $xirr,
                    ':total_goal_current' => $totalGoalCurrent,
                    ':total_goal_target'  => $totalGoalTarget,
                    ':total_sip'          => $totalSip,
                    ':greeting_prefix'    => $greetingBase,
                    ':intro_text'         => $introText,
                    ':closing_text'       => $closingText,
                    ':rationale_text'     => $rationaleText,
                ]);

                $clientId = (int)$pdo->lastInsertId();
                $savedCount++;

                // ----- SAVE GOALS -----
                foreach ($goals as $g) {
                    $stmtGoal->execute([
                        ':client_id'      => $clientId,
                        ':goal'           => $g['goal']          ?? '',
                        ':goal_date'      => $g['goal_date']     ?? '',
                        ':current_amount' => $g['current_value'] ?? 0,
                        ':sip_swp'        => $g['running_sip']   ?? 0,
                        ':target_amount'  => $g['target_amount'] ?? 0,
                        ':projected'      => $g['projected']     ?? 0,
                        ':completion'     => $g['completion']    ?? 0,
                        ':status'         => $g['status']        ?? '',
                    ]);
                }

                // ----- SAVE ALLOCATION -----
                foreach ($allocation as $asset => $share) {
                    $stmtAlloc->execute([
                        ':client_id' => $clientId,
                        ':asset'     => $asset,
                        ':share_pct' => $share,
                    ]);
                }

                // ----- SAVE SCHEMES -----
                foreach ($schemes as $s) {
                    $stmtScheme->execute([
                        ':client_id'          => $clientId,
                        ':scheme_name'        => $s['scheme']        ?? '',
                        ':sip_swp'            => $s['sip_swp']       ?? 0,
                        ':current_value'      => $s['current_value'] ?? 0,
                        ':action_step'        => 'Continue',
                        ':recommended_scheme' => null,
                        ':recommended_amount' => 0,
                    ]);
                }

                // ----- SAVE ANNEXURES -----
                foreach ($annexureLinesForClient as $line) {
                    $line = trim($line);
                    if ($line === '') continue;
                    $stmtAnnex->execute([
                        ':client_id' => $clientId,
                        ':line_text' => $line,
                    ]);
                }

                echo '<h2>' . htmlspecialchars($name) . '</h2>';

                renderClientReport(
                    $data,
                    $greetingBase,
                    $introText,
                    $closingText,
                    $rationaleText,
                    $annexureLinesForClient,
                    $clientId
                );
            }

            if ($savedCount > 0) {
                echo "<div class='flash flash-success'>Successfully saved reports for {$savedCount} client(s).</div>";
            }
        }
        ?>
        <div id="toast" class="toast"></div>

        <script>
            function showToast(msg) {
                const toast = document.getElementById('toast');
                toast.textContent = msg;
                toast.classList.add('show');
                setTimeout(() => {
                    toast.classList.remove('show');
                }, 2000);
            }

            document.querySelectorAll('.edit-btn').forEach(function(btn) {
                btn.addEventListener('click', function () {
                    const block = btn.closest('.editable-block');
                    const span  = block.querySelector('.editable-text');
                    const clientReport = btn.closest('.client-report');
                    const clientId = clientReport ? clientReport.getAttribute('data-client-id') : null;
                    const field = span ? span.getAttribute('data-field') : null;

                    const editing = span.getAttribute('contenteditable') === 'true';

                    if (!editing) {
                        span.setAttribute('contenteditable', 'true');
                        span.focus();
                        btn.textContent = 'Save';
                    } else {
                        span.setAttribute('contenteditable', 'false');
                        btn.textContent = 'Edit';

                        if (clientId && field) {
                            const value = span.innerText.trim();

                            fetch('client_report.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                                },
                                body: new URLSearchParams({
                                    ajax: '1',
                                    client_id: clientId,
                                    field: field,
                                    value: value
                                })
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (!data.success) {
                                    alert('Save failed: ' + (data.error || 'Unknown error'));
                                } else {
                                    showToast('Saved ' + field + ' for client #' + clientId);
                                }
                            })
                            .catch(err => {
                                alert('Save error: ' + err);
                            });
                        }
                    }
                });
            });
        </script>
        </body>
        </html>
        <?php
        exit;

    } catch (Throwable $e) {
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>Error - Client Reports</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .flash-error { padding: 10px; border-radius: 4px; background: #ffe6e6; border: 1px solid #b30000; }
                .nav-button {
                    display: inline-block;
                    margin-top: 10px;
                    padding: 6px 12px;
                    background-color: #0056b3;
                    color: #fff;
                    border-radius: 4px;
                    text-decoration: none;
                    font-size: 13px;
                }
            </style>
        </head>
        <body>
        <div class="flash-error">
            <strong>Unexpected error:</strong><br>
            <?php echo htmlspecialchars($e->getMessage()); ?>
        </div>
        <a href="client_report.php" class="nav-button">Back to Upload</a>
        </body>
        </html>
        <?php
        exit;
    }
}

/* ---------- INITIAL UPLOAD PAGE (GET) ---------- */
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload Client Files</title>
    
    <!-- Modern Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <!-- Modern Styling -->
    <link rel="stylesheet" href="public/css/styles.css">
    
    <style>
        label {
            display: block;
            margin-top: 15px;
            font-weight: 600;
            color: #0288D1;
        }
        
        input[type="file"],
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #E3F2FD;
            border-radius: 8px;
            font-family: 'Inter', sans-serif;
            margin-top: 8px;
        }
        
        input[type="file"]:focus,
        input[type="text"]:focus,
        textarea:focus {
            border-color: #4FC3F7;
            outline: none;
        }
        
        textarea {
            min-height: 100px;
        }
        
        button[type="submit"] {
            margin-top: 20px;
            padding: 12px 30px;
            background: linear-gradient(135deg, #4FC3F7 0%, #29B6F6 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(41, 182, 246, 0.3);
        }
        
        button[type="submit"]:hover {
            background: linear-gradient(135deg, #29B6F6 0%, #0288D1 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(41, 182, 246, 0.4);y>
        }/html>
    </style></head><body><div class="nav-bar">    <a href="client_report.php" class="nav-button">Upload New Files</a>    <a href="view_report.php" class="nav-button">View Saved Reports</a></div><h1>Upload Client Data Files</h1><form method="post" enctype="multipart/form-data">    <label for="client_files">Select Excel &amp; PDF files (multiple allowed):</label>    <input type="file" name="client_files[]" id="client_files" multiple required>    <label for="greeting">Greeting prefix (without name)</label>    <input type="text" name="greeting" id="greeting"           value="<?php echo htmlspecialchars($DEFAULT_GREETING); ?>" />    <label for="intro_text">Default introductory paragraph</label>    <textarea name="intro_text" id="intro_text"><?php echo htmlspecialchars($DEFAULT_INTRO); ?></textarea>    <label for="closing_text">Default closing paragraph</label>    <textarea name="closing_text" id="closing_text"><?php echo htmlspecialchars($DEFAULT_CLOSING); ?></textarea>    <label for="rationale_text">Default rationale text</label>    <textarea name="rationale_text" id="rationale_text"><?php echo htmlspecialchars($DEFAULT_RATIONALE); ?></textarea>    <button type="submit">Create Reports</button></form></body></html>